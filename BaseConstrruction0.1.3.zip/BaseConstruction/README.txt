# Contract-Pack-Base-Construction
A Contract Configurator contract pack for base construction


This Contract Pack supports MKS, KAS, USILS, IFILS and TACLS
The licence is on the BaseConstruction folder
Forum Thread ----http://forum.kerbalspaceprogram.com/threads/127138
Instalation:
CKAN: Search for // Contract Pack: Base Construction
Manual Install
Download Contract Configurator  (Version min 1.5.0)----https://github.com/jrossignol/ContractConfigurator/releases
Install it.
Download Module Manger (Version min 2.6.5)----http://forum.kerbalspaceprogram.com/threads/55219
Install it.
Unzip the BaseConstruction0.1.3.zip
Put the BaseConstruction folder into *KSP*\GameData\ContractPacks\
Run KSP
Done
*KSP*: This is your game library all game folders should be there but this can have any name you want.

