# Contract-Pack-Base-Construction
A Contract Configurator contract pack for base construction

####THIS IS AN ALPHA RELEASE USE IT IN YOUR OWN RISK####

This Contract Pack supports MKS, KAS, USILS, IFILS and TACLS
The licence is on the BaseConstruction folder
Dev Forum Thread ----http://forum.kerbalspaceprogram.com/threads/124301-WIP-Contract-Pack-Base-Construction

Instalation:

Download Contract Configurator  (Version after 1.3.2)---https://github.com/jrossignol/ContractConfigurator/releases
Install it.

Unzip the CPBaseConstruction.zip
Put the ContractPacks folder into KSP\GameData\
Run KSP
Done

